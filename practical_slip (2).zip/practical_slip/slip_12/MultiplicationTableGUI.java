// Slip 12 - Question 2 (Java)
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MultiplicationTableGUI {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Multiplication Table");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JLabel label = new JLabel("Enter a number:");
        JTextField textField = new JTextField(10);
        JButton button = new JButton("Show Table");
        DefaultListModel<String> listModel = new DefaultListModel<>();
        JList<String> listBox = new JList<>(listModel);

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                listModel.clear(); // Clear previous entries
                try {
                    int num = Integer.parseInt(textField.getText());
                    for (int i = 1; i <= 10; i++) {
                        listModel.addElement(num + " x " + i + " = " + (num * i));
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Please enter a valid number!");
                }
            }
        });

        frame.add(label);
        frame.add(textField);
        frame.add(button);
        frame.add(new JScrollPane(listBox));

        frame.setVisible(true);
    }
}
