# Slip 12 - Question 2 (Python)
from collections import Counter

# Sample string
text = 'thequickbrownfoxjumpsoverthelazydog'

# Count all characters
char_count = Counter(text)

# Filter repeated characters (count > 1)
repeated_chars = {char: count for char, count in char_count.items() if count > 1}

# Display result
for char, count in repeated_chars.items():
    print(f"{char}-{count}", end=", ")
