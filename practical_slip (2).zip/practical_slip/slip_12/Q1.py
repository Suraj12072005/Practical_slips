# Slip 12 - Question 1 (Python)
import tkinter as tk
from tkinter import font

def change_font():
    # Update the label font with selected style
    lbl.config(font=(font_name.get(), font_size.get(), 'bold' if bold_var.get() else 'normal'))

# Create main window
root = tk.Tk()
root.title("Label Font Changer")
root.geometry("400x200")

# Label
lbl = tk.Label(root, text="Hello, Tkinter!", font=("Arial", 16))
lbl.pack(pady=20)

# Font name input
tk.Label(root, text="Font Name:").pack()
font_name = tk.StringVar(value="Arial")
tk.Entry(root, textvariable=font_name).pack()

# Font size input
tk.Label(root, text="Font Size:").pack()
font_size = tk.IntVar(value=16)
tk.Entry(root, textvariable=font_size).pack()

# Bold checkbox
bold_var = tk.BooleanVar()
tk.Checkbutton(root, text="Bold", variable=bold_var).pack()

# Button to apply changes
tk.Button(root, text="Change Font", command=change_font).pack(pady=10)

root.mainloop()
