// Slip 12 - Question 1 (Java)
public class ReverseStrings {
    public static void main(String[] args) {
        // Sample String array
        String[] words = {"Java", "Programming", "OpenAI", "ChatGPT"};

        System.out.println("Original Strings:");
        for (String word : words) {
            System.out.println(word);
        }

        System.out.println("\nStrings in Reverse Order:");
        for (String word : words) {
            String reversed = "";
            for (int i = word.length() - 1; i >= 0; i--) {
                reversed += word.charAt(i);
            }
            System.out.println(reversed);
        }
    }
}
