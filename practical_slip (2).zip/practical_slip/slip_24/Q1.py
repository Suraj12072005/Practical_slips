# Slip 24 - Question 1 (Python)
# Function to check if a number is prime
def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n**0.5)+1):
        if n % i == 0:
            return False
    return True

# Function to calculate factorial
def factorial(n):
    if n == 0 or n == 1:
        return 1
    fact = 1
    for i in range(2, n+1):
        fact *= i
    return fact

# Input from user
num = int(input("Enter a number: "))

# Check prime
if is_prime(num):
    print(f"{num} is a prime number.")
else:
    print(f"{num} is not a prime number.")

# Find factorial
print(f"Factorial of {num} is {factorial(num)}")
