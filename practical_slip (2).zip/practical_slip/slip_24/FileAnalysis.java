// Slip 24 - Question 1 (Java)
import java.io.*;

public class FileAnalysis {
    public static void main(String[] args) {
        int digits = 0, spaces = 0, characters = 0;

        try {
            File file = new File("input.txt"); // Make sure input.txt exists in the project folder
            FileReader fr = new FileReader(file);
            int c;

            while ((c = fr.read()) != -1) {
                char ch = (char) c;
                if (Character.isDigit(ch))
                    digits++;
                else if (Character.isWhitespace(ch))
                    spaces++;
                else
                    characters++;
            }
            fr.close();

            System.out.println("Digits: " + digits);
            System.out.println("Spaces: " + spaces);
            System.out.println("Characters: " + characters);
        } catch (IOException e) {
            System.out.println("File not found or error reading file.");
        }
    }
}
