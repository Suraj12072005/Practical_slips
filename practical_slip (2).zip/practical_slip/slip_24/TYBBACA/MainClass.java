// Slip 24 - Question 2 (Java)
package TYBBACA;

import java.util.Scanner;

class Student {
    int Rno;
    String SName;
    float Per;

    Student(int rno, String sName, float per) {
        this.Rno = rno;
        this.SName = sName;
        this.Per = per;
    }

    void disp() {
        System.out.println("Rno: " + Rno + ", Name: " + SName + ", Percentage: " + Per);
    }

    @Override
    protected void finalize() throws Throwable {
        System.out.println("Student object with Rno " + Rno + " is garbage collected.");
        super.finalize();
    }
}

class Teacher {
    int TID;
    String TName;
    String Subject;

    Teacher(int tid, String tName, String subject) {
        this.TID = tid;
        this.TName = tName;
        this.Subject = subject;
    }

    void disp() {
        if (Subject.equalsIgnoreCase("Java")) {
            System.out.println("Teacher ID: " + TID + ", Name: " + TName + ", Subject: " + Subject);
        }
    }

    @Override
    protected void finalize() throws Throwable {
        System.out.println("Teacher object with TID " + TID + " is garbage collected.");
        super.finalize();
    }
}

public class MainClass {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input for Students
        System.out.print("Enter number of students: ");
        int n = sc.nextInt();
        Student[] students = new Student[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Enter details for student " + (i + 1));
            System.out.print("Rno: ");
            int rno = sc.nextInt();
            sc.nextLine(); // consume newline
            System.out.print("Name: ");
            String name = sc.nextLine();
            System.out.print("Percentage: ");
            float per = sc.nextFloat();

            students[i] = new Student(rno, name, per);
        }

        System.out.println("\nStudent Details:");
        for (Student s : students) {
            s.disp();
        }

        // Input for Teachers
        System.out.print("\nEnter number of teachers: ");
        int t = sc.nextInt();
        sc.nextLine(); // consume newline
        Teacher[] teachers = new Teacher[t];

        for (int i = 0; i < t; i++) {
            System.out.println("Enter details for teacher " + (i + 1));
            System.out.print("TID: ");
            int tid = sc.nextInt();
            sc.nextLine(); // consume newline
            System.out.print("Name: ");
            String tname = sc.nextLine();
            System.out.print("Subject: ");
            String subject = sc.nextLine();

            teachers[i] = new Teacher(tid, tname, subject);
        }

        System.out.println("\nTeachers teaching Java:");
        for (Teacher te : teachers) {
            te.disp();
        }

        // Trigger garbage collection
        students = null;
        teachers = null;
        System.gc();
        sc.close();
    }
}
