# Slip 24 - Question 2 (Python)
from tkinter import *

# Mapping of digits to words
digit_words = {
    '0':'Zero', '1':'One', '2':'Two', '3':'Three', '4':'Four',
    '5':'Five', '6':'Six', '7':'Seven', '8':'Eight', '9':'Nine'
}

def show_digits():
    num = entry.get()
    words = [digit_words.get(d, "") for d in num if d.isdigit()]
    result_var.set(" ".join(words))

# GUI setup
root = Tk()
root.title("Number to Words")

Label(root, text="Enter a number:").pack(pady=5)
entry = Entry(root)
entry.pack(pady=5)

Button(root, text="Convert to Words", command=show_digits).pack(pady=5)

result_var = StringVar()
Label(root, textvariable=result_var, fg="blue").pack(pady=5)

root.mainloop()
