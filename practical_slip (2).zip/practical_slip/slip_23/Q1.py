# Slip 23 - Question 1 (Python)
import tkinter as tk
from tkinter import font

def change_font():
    # Get values from entries
    fname = font_name.get()
    fsize = int(font_size.get())
    fbold = 'bold' if bold_var.get() else 'normal'

    # Update label font
    my_font = (fname, fsize, fbold)
    label.config(font=my_font)

# Create main window
root = tk.Tk()
root.title("Change Label Font")

# Create a label
label = tk.Label(root, text="Hello, Tkinter!", font=("Arial", 16))
label.pack(pady=20)

# Font name entry
tk.Label(root, text="Font Name:").pack()
font_name = tk.StringVar(value="Arial")
tk.Entry(root, textvariable=font_name).pack()

# Font size entry
tk.Label(root, text="Font Size:").pack()
font_size = tk.StringVar(value="16")
tk.Entry(root, textvariable=font_size).pack()

# Bold checkbox
bold_var = tk.BooleanVar()
tk.Checkbutton(root, text="Bold", variable=bold_var).pack()

# Button to apply font
tk.Button(root, text="Change Font", command=change_font).pack(pady=10)

root.mainloop()
