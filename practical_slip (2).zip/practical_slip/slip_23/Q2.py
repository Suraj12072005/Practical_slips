# Slip 23 - Question 2 (Python)
import math

class Circle:
    def __init__(self, radius):
        self.radius = radius

    # Overload + operator to add radius of two circles
    def __add__(self, other):
        return Circle(self.radius + other.radius)

    # Method to calculate area
    def area(self):
        return math.pi * self.radius * self.radius

    def display(self):
        print(f"Radius: {self.radius}, Area: {self.area():.2f}")

# Example usage
c1 = Circle(5)
c2 = Circle(3)

print("Circle 1:")
c1.display()
print("Circle 2:")
c2.display()

# Add two circles
c3 = c1 + c2
print("Circle 3 (after adding radii):")
c3.display()
