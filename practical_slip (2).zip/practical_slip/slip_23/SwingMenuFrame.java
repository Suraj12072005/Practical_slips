// Slip 23 - Question 2 (Java)
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SwingMenuFrame {
    public static void main(String[] args) {
        // Create frame
        JFrame frame = new JFrame("Swing Menu Example");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create menu bar
        JMenuBar menuBar = new JMenuBar();

        // File menu
        JMenu fileMenu = new JMenu("File");
        menuBar.add(fileMenu);

        // Edit menu
        JMenu editMenu = new JMenu("Edit");
        menuBar.add(editMenu);

        // Search menu
        JMenu searchMenu = new JMenu("Search");
        menuBar.add(searchMenu);

        // Add items to Edit menu with icons
        editMenu.add(createMenuItem("Undo", "undo.png"));
        editMenu.add(createMenuItem("Redo", "redo.png"));
        editMenu.addSeparator();
        editMenu.add(createMenuItem("Cut", "cut.png"));
        editMenu.add(createMenuItem("Copy", "copy.png"));
        editMenu.add(createMenuItem("Paste", "paste.png"));

        // Set menu bar
        frame.setJMenuBar(menuBar);
        frame.setVisible(true);
    }

    // Helper method to create menu item with icon
    private static JMenuItem createMenuItem(String name, String iconPath) {
        ImageIcon icon = new ImageIcon(iconPath); // Make sure icons are in project folder
        JMenuItem item = new JMenuItem(name, icon);
        return item;
    }
}
