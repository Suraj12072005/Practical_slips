# Slip 9 - Question 2 (Python)
import tkinter as tk
from tkinter import messagebox

def check_number():
    try:
        n = int(entry.get())
    except ValueError:
        messagebox.showerror("Error", "Please enter a valid integer.")
        return

    if var.get() == 1:  # Prime check
        if n > 1 and all(n % i != 0 for i in range(2, int(n**0.5)+1)):
            messagebox.showinfo("Result", f"{n} is a Prime number.")
        else:
            messagebox.showinfo("Result", f"{n} is not a Prime number.")

    elif var.get() == 2:  # Perfect check
        if n > 0 and sum(i for i in range(1, n) if n % i == 0) == n:
            messagebox.showinfo("Result", f"{n} is a Perfect number.")
        else:
            messagebox.showinfo("Result", f"{n} is not a Perfect number.")

    elif var.get() == 3:  # Armstrong check
        digits = [int(d) for d in str(n)]
        if sum(d**len(digits) for d in digits) == n:
            messagebox.showinfo("Result", f"{n} is an Armstrong number.")
        else:
            messagebox.showinfo("Result", f"{n} is not an Armstrong number.")

# GUI setup
root = tk.Tk()
root.title("Number Checker")
root.geometry("350x200")

tk.Label(root, text="Enter a number:").pack(pady=5)
entry = tk.Entry(root)
entry.pack(pady=5)

var = tk.IntVar()
tk.Radiobutton(root, text="Prime", variable=var, value=1).pack()
tk.Radiobutton(root, text="Perfect", variable=var, value=2).pack()
tk.Radiobutton(root, text="Armstrong", variable=var, value=3).pack()

tk.Button(root, text="Check", command=check_number).pack(pady=10)

root.mainloop()
