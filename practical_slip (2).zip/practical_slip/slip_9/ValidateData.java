// Slip 9 - Question 2 (Java)
import java.util.Scanner;

// User-defined Exception
class InvalidDataException extends Exception {
    public InvalidDataException(String message) {
        super(message);
    }
}

public class ValidateData {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter PAN number: ");
        String pan = sc.nextLine();

        System.out.print("Enter Mobile number: ");
        String mobile = sc.nextLine();

        try {
            validatePAN(pan);
            validateMobile(mobile);
            System.out.println("PAN Number: " + pan);
            System.out.println("Mobile Number: " + mobile);
        } catch (InvalidDataException e) {
            System.out.println("Error: " + e.getMessage());
        }

        sc.close();
    }

    // PAN format: 5 letters, 4 digits, 1 letter (e.g., ABCDE1234F)
    public static void validatePAN(String pan) throws InvalidDataException {
        if (!pan.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}")) {
            throw new InvalidDataException("Invalid PAN Number");
        }
    }

    // Mobile number: 10 digits, starts with 6-9
    public static void validateMobile(String mobile) throws InvalidDataException {
        if (!mobile.matches("[6-9][0-9]{9}")) {
            throw new InvalidDataException("Invalid Mobile Number");
        }
    }
}
