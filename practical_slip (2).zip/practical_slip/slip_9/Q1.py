# Slip 9 - Question 1 (Python)
class WordReverser:
    def __init__(self, text):
        self.text = text

    def reverse_words(self):
        words = self.text.split()          # Split the string into words
        reversed_words = words[::-1]       # Reverse the list of words
        return ' '.join(reversed_words)    # Join back into a string

# Example usage
input_text = "Hello world from OpenAI"
reverser = WordReverser(input_text)
print("Original String:", input_text)
print("Reversed Words:", reverser.reverse_words())
