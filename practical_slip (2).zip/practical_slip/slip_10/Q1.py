# Slip 10 - Question 1 (Python)
import tkinter as tk
from tkinter import messagebox

def show_alert():
    messagebox.showinfo("Alert", "Button has been pressed!")

# Create main window
root = tk.Tk()
root.title("Alert Button Example")
root.geometry("300x150")

# Add a button
button = tk.Button(root, text="Press Me", command=show_alert, font=("Arial", 14))
button.pack(pady=50)

root.mainloop()
