// Slip 10 - Question 1 (Java)
import java.util.Scanner;
import java.util.LinkedHashMap;
import java.util.Map;

public class CharacterFrequencyOrdered {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = sc.nextLine();

        // LinkedHashMap preserves insertion order
        LinkedHashMap<Character, Integer> frequencyMap = new LinkedHashMap<>();

        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            frequencyMap.put(ch, frequencyMap.getOrDefault(ch, 0) + 1);
        }

        System.out.println("Character frequencies:");
        for (Map.Entry<Character, Integer> entry : frequencyMap.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }

        sc.close();
    }
}
