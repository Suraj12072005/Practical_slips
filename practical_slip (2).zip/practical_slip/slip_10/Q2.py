# Slip 10 - Question 2 (Python)
class ParenthesesValidator:
    def __init__(self, s):
        self.s = s

    def is_valid(self):
        stack = []
        # Mapping of closing to opening brackets
        mapping = {')': '(', '}': '{', ']': '['}

        for char in self.s:
            if char in mapping.values():  # Opening brackets
                stack.append(char)
            elif char in mapping:  # Closing brackets
                if not stack or stack[-1] != mapping[char]:
                    return False
                stack.pop()
            else:
                # Ignore non-bracket characters (optional)
                continue
        
        return len(stack) == 0

# Example usage
test_strings = ["()", "()[]{}", "[)", "({[)]", "{{{"]
validator = ParenthesesValidator("")

for s in test_strings:
    validator.s = s
    print(f"{s}: {validator.is_valid()}")
