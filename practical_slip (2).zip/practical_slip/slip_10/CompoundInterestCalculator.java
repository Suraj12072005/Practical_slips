import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CompoundInterestCalculator extends JFrame implements ActionListener {
    JTextField pField, rField, tField, totalField, interestField;
    JButton calcBtn, clearBtn, closeBtn;

    CompoundInterestCalculator() {
        setTitle("Compound Interest Calculator");
        setSize(420, 280);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JLabel title = new JLabel("Compound Interest Calculator", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 16));
        title.setBounds(60, 10, 300, 25);
        add(title);

        addLabel("Principal Amount:", 40, 50);
        pField = addField(200, 50);

        addLabel("Interest Rate (%):", 40, 80);
        rField = addField(200, 80);

        addLabel("Time (Yrs):", 280, 80);
        tField = addField(360, 80, 40);

        addLabel("Total Amount:", 40, 110);
        totalField = addField(200, 110);
        totalField.setEditable(false);

        addLabel("Interest Amount:", 40, 140);
        interestField = addField(200, 140);
        interestField.setEditable(false);

        calcBtn = addButton("Calculate", 40, 190);
        clearBtn = addButton("Clear", 160, 190);
        closeBtn = addButton("Close", 280, 190);

        setVisible(true);
        setLocationRelativeTo(null);
    }

    JLabel addLabel(String text, int x, int y) {
        JLabel l = new JLabel(text);
        l.setBounds(x, y, 150, 25);
        add(l);
        return l;
    }

    JTextField addField(int x, int y) {
        return addField(x, y, 120);
    }

    JTextField addField(int x, int y, int w) {
        JTextField t = new JTextField();
        t.setBounds(x, y, w, 25);
        add(t);
        return t;
    }

    JButton addButton(String text, int x, int y) {
        JButton b = new JButton(text);
        b.setBounds(x, y, 100, 30);
        b.addActionListener(this);
        add(b);
        return b;
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == calcBtn) {
            try {
                double p = Double.parseDouble(pField.getText());
                double r = Double.parseDouble(rField.getText());
                double t = Double.parseDouble(tField.getText());
                double total = p * Math.pow((1 + r / 100), t);
                totalField.setText(String.format("%.2f", total));
                interestField.setText(String.format("%.2f", total - p));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid input!");
            }
        } else if (e.getSource() == clearBtn) {
            pField.setText(""); rField.setText(""); tField.setText("");
            totalField.setText(""); interestField.setText("");
        } else dispose();
    }

    public static void main(String[] args) {
        new CompoundInterestCalculator();
    }
}
