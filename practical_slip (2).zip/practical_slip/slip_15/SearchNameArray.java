// Slip 15 - Question 1 (Java)
import java.util.Scanner;

public class SearchNameArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of names: ");
        int n = sc.nextInt();
        sc.nextLine(); // consume newline

        String[] names = new String[n];
        System.out.println("Enter names:");
        for (int i = 0; i < n; i++) {
            names[i] = sc.nextLine();
        }

        System.out.print("Enter name to search: ");
        String searchName = sc.nextLine();

        boolean found = false;
        for (int i = 0; i < n; i++) {
            if (names[i].equalsIgnoreCase(searchName)) {
                System.out.println(searchName + " found at index " + i);
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println(searchName + " not found in the array.");
        }

        sc.close();
    }
}
