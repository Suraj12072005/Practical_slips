# Slip 15 - Question 2 (Python)
def remove_odd_index(s):
    return "".join([s[i] for i in range(len(s)) if i % 2 == 0])

# Accept input from user
string_input = input("Enter a string: ")
result = remove_odd_index(string_input)
print("String after removing characters at odd indices:", result)
