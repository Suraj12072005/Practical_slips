// Slip 15 - Question 2 (Java)
import java.applet.Applet;
import java.awt.*;

/*
<applet code="SmileyFaceApplet.class" width=400 height=400></applet>
*/

public class SmileyFaceApplet extends Applet {

    public void paint(Graphics g) {
        // Face
        g.setColor(Color.YELLOW);
        g.fillOval(50, 50, 300, 300);

        // Eyes
        g.setColor(Color.BLACK);
        g.fillOval(110, 120, 40, 40);
        g.fillOval(250, 120, 40, 40);

        // Smile
        g.drawArc(120, 180, 160, 100, 0, -180);
    }
}
