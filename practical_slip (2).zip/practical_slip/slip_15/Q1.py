# Slip 15 - Question 1 (Python)
class Student:
    def __init__(self, student_name, marks):
        self.student_name = student_name
        self.marks = marks

    def display(self):
        print(f"Name: {self.student_name}, Marks: {self.marks}")

# Original values
student = Student("Alice", 85)
print("Original values:")
student.display()

# Modify attribute values
student.student_name = "Bob"
student.marks = 95
print("\nModified values:")
student.display()
