# Slip 30 - Question 1 (Python)
import tkinter as tk
from tkinter import messagebox

def count_occurrences():
    string = entry_string.get()
    char = entry_char.get()

    if len(char) != 1:
        messagebox.showerror("Error", "Please enter exactly one character!")
        return

    count = string.count(char)
    messagebox.showinfo("Result", f"The character '{char}' occurs {count} times in the string.")

# Create main window
root = tk.Tk()
root.title("Character Occurrence Counter")
root.geometry("400x250")

# Labels and Entry fields
tk.Label(root, text="Enter a String:", font=("Arial", 12)).pack(pady=5)
entry_string = tk.Entry(root, width=40)
entry_string.pack(pady=5)

tk.Label(root, text="Enter a Character:", font=("Arial", 12)).pack(pady=5)
entry_char = tk.Entry(root, width=10)
entry_char.pack(pady=5)

# Button to count
tk.Button(root, text="Count Occurrences", font=("Arial", 12), command=count_occurrences).pack(pady=15)

root.mainloop()
