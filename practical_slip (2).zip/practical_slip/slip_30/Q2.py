# Slip 30 - Question 2 (Python)
# Base class
class Country:
    def __init__(self):
        self.string = ""

    def accept_string(self):
        self.string = input("Enter a string: ")

    def print_string(self):
        print("The entered string is:", self.string)

    def printNationality(self):
        print("Nationality: Indian")

# Subclass
class State(Country):
    def printState(self):
        print("State: Maharashtra")

    def printAll(self):
        # print state, country (from base class), and nationality
        self.printState()
        print("Country: India")
        self.printNationality()

# --- Main Program ---
obj = State()
obj.accept_string()
obj.print_string()
print()  # spacing
obj.printAll()
