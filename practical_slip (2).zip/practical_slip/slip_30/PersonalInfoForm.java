import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PersonalInfoForm extends JFrame implements ActionListener {
    JTextField fName, lName, address, mobile;
    JRadioButton male, female;
    JCheckBox comp, sports, music;
    JButton submit, reset;
    ButtonGroup genderGroup;

    public PersonalInfoForm() {
        setTitle("Personal Information");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(9, 2, 5, 5));

        add(new JLabel("First Name:"));  add(fName = new JTextField());
        add(new JLabel("Last Name:"));   add(lName = new JTextField());
        add(new JLabel("Address:"));     add(address = new JTextField());
        add(new JLabel("Mobile Number:")); add(mobile = new JTextField());

        // Gender
        add(new JLabel("Gender:"));
        male = new JRadioButton("Male"); female = new JRadioButton("Female");
        genderGroup = new ButtonGroup(); genderGroup.add(male); genderGroup.add(female);
        JPanel gPanel = new JPanel(); gPanel.add(male); gPanel.add(female);
        add(gPanel);

        // Interests
        add(new JLabel("Interests:"));
        comp = new JCheckBox("Computer"); sports = new JCheckBox("Sports"); music = new JCheckBox("Music");
        JPanel iPanel = new JPanel(); iPanel.add(comp); iPanel.add(sports); iPanel.add(music);
        add(iPanel);

        // Buttons
        submit = new JButton("Submit"); reset = new JButton("Reset");
        submit.addActionListener(this); reset.addActionListener(this);
        add(submit); add(reset);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submit) {
            String gender = male.isSelected() ? "Male" : female.isSelected() ? "Female" : "Not selected";
            String interests = (comp.isSelected() ? "Computer " : "") +
                               (sports.isSelected() ? "Sports " : "") +
                               (music.isSelected() ? "Music " : "");

            JOptionPane.showMessageDialog(this,
                "Name: " + fName.getText() + " " + lName.getText() +
                "\nAddress: " + address.getText() +
                "\nMobile: " + mobile.getText() +
                "\nGender: " + gender +
                "\nInterests: " + interests);
        } else {
            fName.setText(""); lName.setText(""); address.setText(""); mobile.setText("");
            genderGroup.clearSelection();
            comp.setSelected(false); sports.setSelected(false); music.setSelected(false);
        }
    }

    public static void main(String[] args) {
        new PersonalInfoForm();
    }
}
