// Slip 30 - Question 1 (Java)
import java.util.Scanner;

// Custom Exception for Zero
class NumberIsZeroException extends Exception {
    public NumberIsZeroException(String message) {
        super(message);
    }
}

public class PalindromeCheck {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        String input = sc.nextLine();

        try {
            // Check if input is numeric
            if (!input.matches("-?\\d+")) { // allows optional minus sign
                throw new NumberFormatException("Number is Invalid");
            }

            int num = Integer.parseInt(input);

            // Throw custom exception if number is zero
            if (num == 0) {
                throw new NumberIsZeroException("Number is Zero");
            }

            // Check palindrome
            if (isPalindrome(Math.abs(num))) {
                System.out.println(num + " is a Palindrome.");
            } else {
                System.out.println(num + " is NOT a Palindrome.");
            }

        } catch (NumberIsZeroException e) {
            System.out.println("Exception: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            sc.close();
        }
    }

    // Method to check if number is palindrome
    public static boolean isPalindrome(int number) {
        int original = number;
        int reverse = 0;
        while (number != 0) {
            int digit = number % 10;
            reverse = reverse * 10 + digit;
            number /= 10;
        }
        return original == reverse;
    }
}
