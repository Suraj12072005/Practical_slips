// Slip 13 - Question 1 (Java)
import java.util.ArrayList;
import java.util.Scanner;

public class ReverseArrayList {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Ask user for the number of elements
        System.out.print("Enter the number of integers: ");
        int n = sc.nextInt();

        ArrayList<Integer> numbers = new ArrayList<>();

        // Accept 'n' integers from the user
        System.out.println("Enter " + n + " integers:");
        for (int i = 0; i < n; i++) {
            int num = sc.nextInt();
            numbers.add(num);
        }

        // Display elements in reverse order
        System.out.println("ArrayList elements in reverse order:");
        for (int i = numbers.size() - 1; i >= 0; i--) {
            System.out.print(numbers.get(i) + " ");
        }
        
        sc.close();
    }
}
