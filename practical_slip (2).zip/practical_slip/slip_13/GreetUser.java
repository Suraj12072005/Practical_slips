// Slip 13 - Question 2 (Java)
import java.util.Scanner;

public class GreetUser {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Ask user for their name
        System.out.print("Enter your name: ");
        String name = sc.nextLine();

        // Convert name to uppercase and greet
        String upperName = name.toUpperCase();
        System.out.println("Hello, " + upperName + ", nice to meet you!");

        sc.close();
    }
}
