# Slip 13 - Question 2 (Python)
class Queue:
    def __init__(self):
        self.queue = []

    # Enqueue operation
    def enqueue(self, item):
        self.queue.append(item)
        print(f"{item} added to the queue.")

    # Dequeue operation
    def dequeue(self):
        if len(self.queue) == 0:
            print("Queue is empty. Cannot dequeue.")
        else:
            removed_item = self.queue.pop(0)
            print(f"{removed_item} removed from the queue.")

    # Display queue
    def display(self):
        if len(self.queue) == 0:
            print("Queue is empty.")
        else:
            print("Queue elements:", self.queue)

# Using the Queue
q = Queue()
q.enqueue(10)
q.enqueue(20)
q.enqueue(30)
q.display()
q.dequeue()
q.display()
q.dequeue()
q.dequeue()
q.dequeue()  # Trying to remove from empty queue
