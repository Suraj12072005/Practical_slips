# Slip 13 - Question 1 (Python)
def input_positive_integer():
    try:
        num = int(input("Enter a positive integer: "))
        if num <= 0:
            raise ValueError("The number is not positive.")
        print("You entered a valid positive integer:", num)
    except ValueError as e:
        print("Invalid input:", e)

# Call the function
input_positive_integer()
