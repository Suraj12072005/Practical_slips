// Slip 2 - Question 2 (Java)

// Program B: Handle Mouse Events and display Mouse Click position
import java.awt.*;
import java.awt.event.*;

public class MouseEventsDemo extends Frame implements MouseListener, MouseMotionListener {
    TextField tf;

    MouseEventsDemo() {
        // Create a TextField to display mouse position
        tf = new TextField(30);
        tf.setEditable(false);

        add(tf, BorderLayout.SOUTH);
        addMouseListener(this);
        addMouseMotionListener(this);

        setSize(400, 300);
        setTitle("Mouse Events Demo");
        setVisible(true);
    }

    // MouseListener methods
    public void mouseClicked(MouseEvent e) {
        tf.setText("Mouse Clicked at: X = " + e.getX() + ", Y = " + e.getY());
    }
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}

    // MouseMotionListener methods
    public void mouseDragged(MouseEvent e) {}
    public void mouseMoved(MouseEvent e) {
        setTitle("Mouse Moved at: X = " + e.getX() + ", Y = " + e.getY());
    }

    public static void main(String[] args) {
        new MouseEventsDemo();
    }
}
