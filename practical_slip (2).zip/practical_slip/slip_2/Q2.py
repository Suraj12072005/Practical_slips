# Slip 2 - Question 2 (Python)
import tkinter as tk
from time import strftime

# Function to update the time every second
def time():
    current_time = strftime('%H:%M:%S %p')  # 24-hour format with AM/PM
    label.config(text=current_time)
    label.after(1000, time)  # Update every 1 second

# Create main window
root = tk.Tk()
root.title("Digital Clock")

# Label to show time
label = tk.Label(root, font=('calibri', 50, 'bold'), background='black', foreground='cyan')
label.pack(anchor='center', pady=20)

# Start the clock
time()

# Run the GUI loop
root.mainloop()
