# Slip 2 - Question 1 (Python)
# Function to count uppercase and lowercase letters in a string

def count_case(s):
    upper_count = 0
    lower_count = 0
    
    for char in s:
        if char.isupper():
            upper_count += 1
        elif char.islower():
            lower_count += 1
    
    print("No. of Upper case characters:", upper_count)
    print("No. of Lower case characters:", lower_count)


# Sample string
sample_string = 'The quick Brown Fox'
print("Sample String:", sample_string)

# Call the function
count_case(sample_string)
