// Slip 6 - Question 1 (Java)
import java.util.Scanner;

// Custom Exception
class NumberIsZeroException extends Exception {
    public NumberIsZeroException(String message) {
        super(message);
    }
}

public class SumFirstLastDigit {

    // Static method to calculate sum of first and last digit
    public static int sumFirstLast(int num) {
        int lastDigit = num % 10;
        int firstDigit = num;
        while (firstDigit >= 10) {
            firstDigit /= 10;
        }
        return firstDigit + lastDigit;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int number = sc.nextInt();

        try {
            if (number == 0) {
                throw new NumberIsZeroException("Number Is Zero");
            } else {
                int sum = sumFirstLast(number);
                System.out.println("Sum of first and last digit: " + sum);
            }
        } catch (NumberIsZeroException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        sc.close();
    }
}
