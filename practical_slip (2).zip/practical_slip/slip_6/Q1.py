# Slip 6 - Question 1 (Python)
import math

# Function for cube
def cube_area_volume(side):
    area = 6 * side ** 2
    volume = side ** 3
    return area, volume

# Function for sphere
def sphere_area_volume(radius):
    area = 4 * math.pi * radius ** 2
    volume = (4/3) * math.pi * radius ** 3
    return area, volume

# Main program
print("Cube Calculation")
side = float(input("Enter the side of the cube: "))
cube_area, cube_volume = cube_area_volume(side)
print(f"Cube Surface Area: {cube_area}")
print(f"Cube Volume: {cube_volume}")

print("\nSphere Calculation")
radius = float(input("Enter the radius of the sphere: "))
sphere_area, sphere_volume = sphere_area_volume(radius)
print(f"Sphere Surface Area: {sphere_area}")
print(f"Sphere Volume: {sphere_volume}")
