# Slip 6 - Question 2 (Python)
import tkinter as tk
from tkinter import font

# Function to update font
def update_font():
    f_style = ""
    if bold_var.get():
        f_style += "bold "
    if italic_var.get():
        f_style += "italic"
    lbl_font.config(weight="bold" if bold_var.get() else "normal",
                    slant="italic" if italic_var.get() else "roman",
                    size=size_var.get())
    label.config(font=lbl_font)

# Create main window
root = tk.Tk()
root.title("Font Style Changer")

# Variables for checkbuttons
bold_var = tk.IntVar()
italic_var = tk.IntVar()
size_var = tk.IntVar(value=12)

# Label
lbl_font = font.Font(family="Arial", size=12)
label = tk.Label(root, text="Hello, World!", font=lbl_font)
label.pack(pady=10)

# Checkbuttons
bold_cb = tk.Checkbutton(root, text="Bold", variable=bold_var, command=update_font)
bold_cb.pack()
italic_cb = tk.Checkbutton(root, text="Italic", variable=italic_var, command=update_font)
italic_cb.pack()

# Scale to adjust font size
size_scale = tk.Scale(root, from_=8, to=40, orient=tk.HORIZONTAL, label="Font Size", variable=size_var, command=lambda e: update_font())
size_scale.pack()

root.mainloop()
