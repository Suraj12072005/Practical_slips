# Slip 7 - Question 1 (Python)
class ComplexNumber:
    def __init__(self, real, imag):
        self.real = real
        self.imag = imag

    # Overload the + operator
    def __add__(self, other):
        return ComplexNumber(self.real + other.real, self.imag + other.imag)

    def __str__(self):
        # Format the complex number as a+bi
        if self.imag >= 0:
            return f"{self.real}+{self.imag}i"
        else:
            return f"{self.real}{self.imag}i"

# Example usage
c1 = ComplexNumber(3, 4)
c2 = ComplexNumber(5, -2)

c3 = c1 + c2
print("First Complex Number:", c1)
print("Second Complex Number:", c2)
print("Sum:", c3)
