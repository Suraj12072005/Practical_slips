// Slip 7 - Question 1 (Java)
import javax.swing.*;
import java.awt.*;

public class LabelDemo {
    public static void main(String[] args) {
        JFrame f = new JFrame("Label Example");
        JLabel lbl = new JLabel("Dr. D Y Patil College", JLabel.CENTER);
        
        lbl.setFont(new Font("Arial", Font.BOLD, 20)); // Font size 20
        lbl.setOpaque(true);
        lbl.setBackground(Color.RED); // Background color red
        lbl.setForeground(Color.WHITE); // Text color white for visibility
        
        f.add(lbl);
        f.setSize(400, 200);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
    }
}
