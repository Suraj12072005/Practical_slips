# Slip 7 - Question 2 (Python)
import tkinter as tk
from tkinter import messagebox
import random
import string

def generate_password():
    length = 10  # Length of password
    if not length:
        messagebox.showerror("Error", "Password length required")
        return

    # Characters to include: uppercase + lowercase
    chars = string.ascii_letters
    password = ''.join(random.choice(chars) for _ in range(length))
    password_var.set(password)

# GUI setup
root = tk.Tk()
root.title("Random Password Generator")
root.geometry("300x150")

tk.Label(root, text="Generated Password:").pack(pady=5)

password_var = tk.StringVar()
tk.Entry(root, textvariable=password_var, width=30, state='readonly').pack(pady=5)

tk.Button(root, text="Generate Password", command=generate_password).pack(pady=10)

root.mainloop()
