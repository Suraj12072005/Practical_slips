// Slip 7 - Question 2 (Java)
import java.util.*;

class Player {
    int pid, innings, notOut;
    String name;
    double runs, average;

    void getData(Scanner sc) {
        System.out.print("Enter Player ID: ");
        pid = sc.nextInt();
        System.out.print("Enter Player Name: ");
        name = sc.next();
        System.out.print("Enter Total Runs: ");
        runs = sc.nextDouble();
        System.out.print("Enter Innings Played: ");
        innings = sc.nextInt();
        System.out.print("Enter Not Out Times: ");
        notOut = sc.nextInt();
        average = (innings - notOut) > 0 ? runs / (innings - notOut) : runs;
    }

    void display() {
        System.out.println(pid + "\t" + name + "\t" + runs + "\t" + innings + "\t" + notOut + "\t" + String.format("%.2f", average));
    }
}

public class CricketPlayers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of players: ");
        int n = sc.nextInt();

        Player[] p = new Player[n];
        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Player " + (i + 1));
            p[i] = new Player();
            p[i].getData(sc);
        }

        Player max = p[0];
        for (int i = 1; i < n; i++) {
            if (p[i].average > max.average)
                max = p[i];
        }

        System.out.println("\nPID\tName\tRuns\tInnings\tNotOut\tAverage");
        for (Player pl : p)
            pl.display();

        System.out.println("\nPlayer with Maximum Average:");
        max.display();
    }
}
