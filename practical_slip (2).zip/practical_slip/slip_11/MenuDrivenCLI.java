// Slip 11 - Question 1 (Java)
public class MenuDrivenCLI {
    public static void main(String[] args) {
        if(args.length < 3) {
            System.out.println("Usage: java MenuDrivenCLI <operation> <num1> <num2>");
            System.out.println("Operations: add, sub, mul, div");
            return;
        }

        String operation = args[0].toLowerCase();
        double num1 = Double.parseDouble(args[1]);
        double num2 = Double.parseDouble(args[2]);
        double result = 0;

        switch(operation) {
            case "add":
                result = num1 + num2;
                System.out.println("Addition: " + result);
                break;
            case "sub":
                result = num1 - num2;
                System.out.println("Subtraction: " + result);
                break;
            case "mul":
                result = num1 * num2;
                System.out.println("Multiplication: " + result);
                break;
            case "div":
                if(num2 != 0) {
                    result = num1 / num2;
                    System.out.println("Division: " + result);
                } else {
                    System.out.println("Division by zero is not allowed!");
                }
                break;
            default:
                System.out.println("Invalid operation! Use add, sub, mul, or div.");
        }
    }
}
