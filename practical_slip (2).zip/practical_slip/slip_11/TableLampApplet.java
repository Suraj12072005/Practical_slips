// Slip 11 - Question 2 (Java)
import java.applet.Applet;
import java.awt.*;
import java.util.Random;

public class TableLampApplet extends Applet {
    Color lampColor;
    Random rand = new Random();

    public void init() {
        // Set initial random color
        lampColor = new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
    }

    public void paint(Graphics g) {
        // Draw table
        g.setColor(new Color(139, 69, 19)); // Brown color
        g.fillRect(50, 200, 200, 20);

        // Draw lamp stand
        g.setColor(Color.GRAY);
        g.fillRect(140, 100, 20, 100);

        // Draw lamp shade with random color
        g.setColor(lampColor);
        g.fillOval(100, 50, 100, 70);
    }

    public void mouseClicked(java.awt.event.MouseEvent e) {
        // Change lamp color randomly when clicked
        lampColor = new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
        repaint();
    }
}
