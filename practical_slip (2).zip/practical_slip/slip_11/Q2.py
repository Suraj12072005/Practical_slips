# Slip 11 - Question 2 (Python)
import tkinter as tk

def change_color(color):
    root.config(bg=color)

# Create main window
root = tk.Tk()
root.title("Background Color Changer")
root.geometry("400x300")

# Create menu bar
menu_bar = tk.Menu(root)
root.config(menu=menu_bar)

# Create "Colors" menu
color_menu = tk.Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="Colors", menu=color_menu)

# Add color options
colors = ["Red", "Green", "Blue", "Yellow", "Pink", "Cyan"]
for color in colors:
    color_menu.add_command(label=color, command=lambda c=color: change_color(c.lower()))

# Add a label for demonstration
label = tk.Label(root, text="Select a color from the menu", font=("Arial", 14))
label.pack(pady=100)

root.mainloop()
