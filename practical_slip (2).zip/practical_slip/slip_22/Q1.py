# Slip 22 - Question 1 (Python)
class RepeatString:
    def __init__(self, text):
        self.text = text

    # Overload * operator
    def __mul__(self, n):
        return self.text * n

# Accept input from user
string_input = input("Enter a string: ")
n = int(input("Enter number of repetitions: "))

repeat_obj = RepeatString(string_input)
result = repeat_obj * n  # Calls __mul__ method

print("Result:", result)
