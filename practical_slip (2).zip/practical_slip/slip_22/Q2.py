# Slip 22 - Question 2 (Python)
# Accept list from user
lst = list(map(int, input("Enter numbers separated by space: ").split()))

# Bubble Sort
n = len(lst)
for i in range(n-1):
    for j in range(n-1-i):
        if lst[j] > lst[j+1]:
            # Swap elements
            lst[j], lst[j+1] = lst[j+1], lst[j]

print("Sorted list:", lst)
