// Slip 22 - Question 2 (Java)
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class FileOperations {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter file name to create: ");
        String fileName = sc.nextLine();
        File file = new File(fileName);

        // 1. Create a file
        try {
            if (file.createNewFile()) {
                System.out.println("File created successfully: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file.");
        }

        // 2. Rename the file
        System.out.print("Enter new name for the file: ");
        String newName = sc.nextLine();
        File newFile = new File(newName);
        if (file.renameTo(newFile)) {
            System.out.println("File renamed to: " + newFile.getName());
        } else {
            System.out.println("Failed to rename file.");
        }

        // 3. Display path of the file
        System.out.println("File path: " + newFile.getAbsolutePath());

        // 4. Delete the file
        System.out.print("Do you want to delete the file? (yes/no): ");
        String choice = sc.nextLine();
        if (choice.equalsIgnoreCase("yes")) {
            if (newFile.delete()) {
                System.out.println("File deleted successfully.");
            } else {
                System.out.println("Failed to delete the file.");
            }
        }

        sc.close();
    }
}
