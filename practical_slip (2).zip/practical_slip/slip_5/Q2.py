# Slip 5 - Question 2 (Python)
# Generator function for Fibonacci series
def fibonacci(n):
    a, b = 0, 1
    for _ in range(n):
        yield a
        a, b = b, a + b

# Main program
terms = int(input("Enter number of Fibonacci terms: "))
print("Fibonacci series:")
for num in fibonacci(terms):
    print(num, end=" ")
