// Slip 5 - Question 1 (Java)
public class PatternDisplay {
    public static void main(String[] args) {
        for (int i = 5; i >= 1; i--) {   // start row from 5 down to 1
            for (int j = i; j <= 5; j++) { // print numbers from i to 5
                System.out.print(j + " ");
            }
            System.out.println(); // new line after each row
        }
    }
}
