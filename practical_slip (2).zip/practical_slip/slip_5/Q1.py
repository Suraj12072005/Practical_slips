# Slip 5 - Question 1 (Python)
# Define the class
class StringProcessor:
    def __init__(self):
        self.text = ""

    def get_String(self):
        self.text = input("Enter a string: ")

    def print_String(self):
        print("String in uppercase:", self.text.upper())

# Main program
obj = StringProcessor()
obj.get_String()
obj.print_String()
