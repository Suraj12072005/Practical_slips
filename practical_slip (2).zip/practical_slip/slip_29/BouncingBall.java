// Slip 29 - Question 2 (Java)
import java.applet.*;
import java.awt.*;

/*
<applet code="BouncingBall.class" width=400 height=400>
</applet>
*/

public class BouncingBall extends Applet implements Runnable {
    int x = 150, y = 50;          // initial position of ball
    int radius = 30;              // radius of ball
    int dx = 3, dy = 3;           // velocity
    Color ballColor = Color.red;  // initial color
    Thread t;

    public void init() {
        setBackground(Color.black);
        t = new Thread(this);
        t.start();
    }

    public void run() {
        while (true) {
            // Move the ball
            x += dx;
            y += dy;

            // Bounce off the walls
            if (x < 0 || x > getWidth() - radius) {
                dx = -dx;
                changeColor();
            }
            if (y < 0 || y > getHeight() - radius) {
                dy = -dy;
                changeColor();
            }

            repaint();

            try {
                Thread.sleep(20); // delay for animation speed
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void changeColor() {
        // Generate random color on each bounce
        ballColor = new Color(
            (float)Math.random(),
            (float)Math.random(),
            (float)Math.random()
        );
    }

    public void paint(Graphics g) {
        g.setColor(ballColor);
        g.fillOval(x, y, radius, radius);
    }
}
