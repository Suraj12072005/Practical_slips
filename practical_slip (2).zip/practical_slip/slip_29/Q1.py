# Slip 29 - Question 1 (Python)
import tkinter as tk
from tkinter import messagebox
import math

def calculate_volume():
    try:
        radius = float(entry.get())
        volume = (4/3) * math.pi * radius**3
        result_label.config(text=f"Volume of Sphere: {volume:.2f}")
    except ValueError:
        messagebox.showerror("Invalid Input", "Please enter a valid number for radius.")

# GUI setup
root = tk.Tk()
root.title("Sphere Volume Calculator")
root.geometry("300x200")

tk.Label(root, text="Enter Radius:").pack(pady=5)
entry = tk.Entry(root)
entry.pack(pady=5)

tk.Button(root, text="Calculate Volume", command=calculate_volume).pack(pady=10)
result_label = tk.Label(root, text="")
result_label.pack(pady=10)

root.mainloop()
