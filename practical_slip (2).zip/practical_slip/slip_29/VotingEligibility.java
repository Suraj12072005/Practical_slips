// Slip 29 - Question 1 (Java)
import java.util.Scanner;

class InvalidAgeException extends Exception {
    public InvalidAgeException(String message) {
        super(message);
    }
}

public class VotingEligibility {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Enter age: ");
            int age = sc.nextInt();

            if (age < 0) {
                throw new InvalidAgeException("Age cannot be negative.");
            } else if (age >= 18) {
                System.out.println("Candidate is eligible to vote.");
            } else {
                System.out.println("Candidate is NOT eligible to vote.");
            }
        } catch (InvalidAgeException e) {
            System.out.println("User-defined Exception: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("System-defined Exception: " + e);
        } finally {
            sc.close();
        }
    }
}
