# Slip 29 - Question 2 (Python)
# Sample dictionary
data = {'banana': 3, 'apple': 5, 'orange': 2, 'grape': 4}

# Sort by key
asc_key = dict(sorted(data.items()))
desc_key = dict(sorted(data.items(), reverse=True))

# Sort by value
asc_value = dict(sorted(data.items(), key=lambda item: item[1]))
desc_value = dict(sorted(data.items(), key=lambda item: item[1], reverse=True))

# Display results
print("Ascending by Key:", asc_key)
print("Descending by Key:", desc_key)
print("Ascending by Value:", asc_value)
print("Descending by Value:", desc_value)
