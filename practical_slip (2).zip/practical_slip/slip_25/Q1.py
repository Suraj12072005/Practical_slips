# Slip 25 - Question 1 (Python)
def count_case(s):
    upper_count = sum(1 for c in s if c.isupper())
    lower_count = sum(1 for c in s if c.islower())
    print("No. of Upper case characters:", upper_count)
    print("No. of Lower case characters:", lower_count)

# Sample usage
sample_string = 'The quick Brow Fox'
count_case(sample_string)
