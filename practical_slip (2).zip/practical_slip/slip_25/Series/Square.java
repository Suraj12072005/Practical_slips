package Series;

public class Square {
    public void printSquare(int n) {
        System.out.print("Square Series: ");
        for (int i = 1; i <= n; i++) {
            System.out.print((i * i) + " ");
        }
        System.out.println();
    }
}
