import java.util.Scanner;
import Series.Fibonacci;
import Series.Square;
import Series.Cube;

public class SeriesMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = -1;
        while (n < 0) {
            System.out.print("Enter number of terms (n >= 0): ");
            if (sc.hasNextInt()) {
                n = sc.nextInt();
                if (n < 0) {
                    System.out.println("Please enter a non-negative number.");
                }
            } else {
                System.out.println("Invalid input. Please enter an integer.");
                sc.next(); // discard invalid input
            }
        }

        // Create objects of classes from package Series
        Fibonacci f = new Fibonacci();
        Square s = new Square();
        Cube c = new Cube();

        // Call methods
        System.out.println("\nFibonacci Series:");
        f.printFibonacci(n);

        System.out.println("\nSquare Series:");
        s.printSquare(n);

        System.out.println("\nCube Series:");
        c.printCube(n);

        sc.close();
    }
}
