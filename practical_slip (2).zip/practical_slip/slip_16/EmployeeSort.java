// Slip 16 - Question 2 (Java)
import java.util.Scanner;
import java.util.Arrays;

class Employee {
    String name;
    static int count = 0;

    // Method to accept employee name
    void accept(Scanner sc) {
        System.out.print("Enter employee name: ");
        name = sc.nextLine();
        count++;
    }

    // Display method
    void display() {
        System.out.println(name);
    }
}

public class EmployeeSort {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of employees: ");
        int n = sc.nextInt();
        sc.nextLine(); // consume newline

        Employee[] employees = new Employee[n];

        // Accept employee names
        for (int i = 0; i < n; i++) {
            employees[i] = new Employee();
            employees[i].accept(sc);
        }

        // Sort employee names in ascending order
        String[] names = new String[n];
        for (int i = 0; i < n; i++) {
            names[i] = employees[i].name;
        }
        Arrays.sort(names);

        // Display sorted names
        System.out.println("\nSorted Employee Names:");
        for (String name : names) {
            System.out.println(name);
        }

        System.out.println("\nTotal Employees Entered (Static count): " + Employee.count);
        sc.close();
    }
}
