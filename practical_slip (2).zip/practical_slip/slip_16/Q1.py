# Slip 16 - Question 1 (Python)
class Rectangle:
    def __init__(self, length, width):
        self.length = length
        self.width = width

    def area(self):
        return self.length * self.width

    def perimeter(self):
        return 2 * (self.length + self.width)

# Accept input from user
length = float(input("Enter length of rectangle: "))
width = float(input("Enter width of rectangle: "))

# Create Rectangle object
rect = Rectangle(length, width)

# Display area and perimeter
print("Area of rectangle:", rect.area())
print("Perimeter of rectangle:", rect.perimeter())
