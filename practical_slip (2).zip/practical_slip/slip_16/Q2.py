import tkinter as tk
from tkinter import messagebox

def add_item():
    item = entry.get()
    if item: listbox.insert(tk.END, item); entry.delete(0, tk.END)

def print_item():
    for i in listbox.curselection(): print(listbox.get(i))

def delete_item():
    for i in reversed(listbox.curselection()): listbox.delete(i)

root = tk.Tk()
root.title("Listbox Example")

entry = tk.Entry(root); entry.pack(pady=5)
listbox = tk.Listbox(root, selectmode=tk.MULTIPLE, width=40); listbox.pack(pady=10)

tk.Button(root, text="Add", command=add_item).pack(pady=2)
tk.Button(root, text="Print", command=print_item).pack(pady=2)
tk.Button(root, text="Delete", command=delete_item).pack(pady=2)

root.mainloop()
