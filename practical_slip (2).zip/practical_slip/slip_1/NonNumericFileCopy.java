// Slip 1 - Question 2 (Java)
import java.io.*;

public class NonNumericFileCopy {
    public static void main(String[] args) {
        File inputFile = new File("source.txt");
        File outputFile = new File("destination.txt");

        try (
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))
        ) {
            int ch;
            while ((ch = reader.read()) != -1) {
                char character = (char) ch;
                if (!Character.isDigit(character)) {
                    writer.write(character);
                }
            }
            System.out.println("Non-numeric data copied successfully.");
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
