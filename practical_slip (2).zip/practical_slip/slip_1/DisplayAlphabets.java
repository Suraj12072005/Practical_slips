// Slip 1 - Question 1 (Java)
public class DisplayAlphabets {
    public static void main(String[] args) {
        System.out.println("Characters from A to Z:");
        for (char ch = 'A'; ch <= 'Z'; ch++) {
            System.out.print(ch + " ");
        }
    }
}
