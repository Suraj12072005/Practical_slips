# Slip 1 - Question 2 (Python)
import tkinter as tk
from tkinter import messagebox
from datetime import date, datetime

def calculate_age():
    try:
        birthdate_str = entry_birthdate.get()
        birthdate = datetime.strptime(birthdate_str, "%Y-%m-%d").date()
        today = date.today()
        age = today.year - birthdate.year - ((today.month, today.day) < (birthdate.month, birthdate.day))
        messagebox.showinfo("Your Age", f"You are {age} years old.")
    except ValueError:
        messagebox.showerror("Error", "Please enter date in YYYY-MM-DD format")

# Create GUI window
root = tk.Tk()
root.title("Age Calculator")

# GUI layout
label = tk.Label(root, text="Enter your birthdate (YYYY-MM-DD):")
label.pack(pady=10)

entry_birthdate = tk.Entry(root, width=25)
entry_birthdate.pack(pady=5)

btn_calculate = tk.Button(root, text="Calculate Age", command=calculate_age)
btn_calculate.pack(pady=10)

root.mainloop()
