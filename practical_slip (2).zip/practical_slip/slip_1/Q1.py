# Slip 1 - Question 1 (Python)
# Program to accept n numbers and remove duplicates

# Accept number of elements
n = int(input("Enter how many numbers you want: "))

# Create an empty list
numbers = []

# Accept n numbers
for i in range(n):
    num = int(input(f"Enter number {i+1}: "))
    numbers.append(num)

print("\nOriginal list:", numbers)

# Remove duplicates using set, then convert back to list
unique_numbers = list(set(numbers))

print("List after removing duplicates:", unique_numbers)
