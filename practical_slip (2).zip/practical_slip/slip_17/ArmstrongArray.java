// Slip 17 - Question 1 (Java)
import java.util.ArrayList;

public class ArmstrongArray {
    
    // Method to check Armstrong number
    public static boolean isArmstrong(int num) {
        int sum = 0, temp = num;
        int digits = String.valueOf(num).length();

        while (temp != 0) {
            int digit = temp % 10;
            sum += Math.pow(digit, digits);
            temp /= 10;
        }

        return sum == num;
    }

    public static void main(String[] args) {
        ArrayList<Integer> armstrongNumbers = new ArrayList<>();

        for (String arg : args) {
            try {
                int num = Integer.parseInt(arg);
                if (isArmstrong(num)) {
                    armstrongNumbers.add(num);
                }
            } catch (NumberFormatException e) {
                System.out.println(arg + " is not a valid integer.");
            }
        }

        System.out.println("Armstrong Numbers: " + armstrongNumbers);
    }
}
