# Slip 17 - Question 2 (Python)
# Define custom exception
class InvalidDateException(Exception):
    def __init__(self, message):
        super().__init__(message)

# Date class
class Date:
    def __init__(self, day, month, year):
        self.day = day
        self.month = month
        self.year = year
        self.validate()

    def validate(self):
        # Basic validation
        if self.month < 1 or self.month > 12:
            raise InvalidDateException("Month must be between 1 and 12")
        if self.day < 1 or self.day > 31:
            raise InvalidDateException("Day must be between 1 and 31")
        # Check for months with 30 days
        if self.month in [4, 6, 9, 11] and self.day > 30:
            raise InvalidDateException(f"Month {self.month} has only 30 days")
        # February check (not considering leap years for simplicity)
        if self.month == 2 and self.day > 28:
            raise InvalidDateException("February has only 28 days")

    def display(self):
        print(f"Date: {self.day:02d}/{self.month:02d}/{self.year}")

# Accept input from user
try:
    d = int(input("Enter day: "))
    m = int(input("Enter month: "))
    y = int(input("Enter year: "))

    date_obj = Date(d, m, y)
    date_obj.display()

except InvalidDateException as e:
    print("Invalid Date Exception:", e)
except ValueError:
    print("Please enter valid integer values for day, month, and year")
