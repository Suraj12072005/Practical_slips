// Slip 17 - Question 2 (Java)
import java.util.Scanner;

class Product {
    int pid;
    String pname;
    double price;
    int qty;

    // Method to accept product details
    void accept(Scanner sc) {
        System.out.print("Enter Product ID: ");
        pid = sc.nextInt();
        sc.nextLine(); // consume newline
        System.out.print("Enter Product Name: ");
        pname = sc.nextLine();
        System.out.print("Enter Product Price: ");
        price = sc.nextDouble();
        System.out.print("Enter Quantity: ");
        qty = sc.nextInt();
    }

    // Method to display product details and total amount
    void display() {
        double total = price * qty;
        System.out.println("Product ID: " + pid + ", Name: " + pname + ", Price: " + price +
                           ", Quantity: " + qty + ", Total: " + total);
    }
}

public class ProductArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of products: ");
        int n = sc.nextInt();

        Product[] products = new Product[n];

        // Accept product details
        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Product " + (i + 1) + ":");
            products[i] = new Product();
            products[i].accept(sc);
        }

        // Display product details
        System.out.println("\nProduct Details:");
        for (Product p : products) {
            p.display();
        }

        sc.close();
    }
}
