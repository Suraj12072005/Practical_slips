# Slip 17 - Question 1 (Python)
import tkinter as tk
from tkinter import messagebox

def to_uppercase():
    text = entry.get()
    if text:
        result_var.set(text.upper())
    else:
        messagebox.showwarning("Input Error", "Please enter a string")

# Create main window
root = tk.Tk()
root.title("Uppercase Converter")

# Entry widget
tk.Label(root, text="Enter a string:").pack(pady=5)
entry = tk.Entry(root, width=30)
entry.pack(pady=5)

# Button to convert to uppercase
tk.Button(root, text="Convert to Uppercase", command=to_uppercase).pack(pady=5)

# Label to display result
result_var = tk.StringVar()
tk.Label(root, textvariable=result_var, font=("Arial", 14), fg="blue").pack(pady=10)

root.mainloop()
