# Slip 14 - Question 2 (Python)
def caesar_encrypt(text, shift):
    result = ""
    for char in text:
        if char.isalpha():
            # Preserve case
            base = ord('A') if char.isupper() else ord('a')
            result += chr((ord(char) - base + shift) % 26 + base)
        else:
            result += char  # Non-alphabetic characters unchanged
    return result

# Accept input from user
plain_text = input("Enter plain text: ")
shift = int(input("Enter shift value (key): "))

cipher_text = caesar_encrypt(plain_text, shift)

print("Plain Text:", plain_text)
print("Cipher Text:", cipher_text)
