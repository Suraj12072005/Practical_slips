// Slip 14 - Question 2 (Java)
import javax.swing.*;
import java.awt.event.*;

class EmployeeDetailsFrame extends JFrame implements ActionListener {
    JTextField txtEno, txtEName, txtSal;
    JButton btnSubmit;

    EmployeeDetailsFrame() {
        setTitle("Employee Details");
        setSize(300, 200);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel lblEno = new JLabel("Employee No:");
        lblEno.setBounds(20, 20, 100, 25);
        add(lblEno);

        txtEno = new JTextField();
        txtEno.setBounds(130, 20, 120, 25);
        add(txtEno);

        JLabel lblEName = new JLabel("Employee Name:");
        lblEName.setBounds(20, 60, 100, 25);
        add(lblEName);

        txtEName = new JTextField();
        txtEName.setBounds(130, 60, 120, 25);
        add(txtEName);

        JLabel lblSal = new JLabel("Salary:");
        lblSal.setBounds(20, 100, 100, 25);
        add(lblSal);

        txtSal = new JTextField();
        txtSal.setBounds(130, 100, 120, 25);
        add(txtSal);

        btnSubmit = new JButton("Submit");
        btnSubmit.setBounds(80, 140, 100, 30);
        btnSubmit.addActionListener(this);
        add(btnSubmit);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String eno = txtEno.getText();
        String ename = txtEName.getText();
        String sal = txtSal.getText();

        // Open a new frame to display employee details
        new DisplayFrame(eno, ename, sal);
    }

    public static void main(String[] args) {
        new EmployeeDetailsFrame();
    }
}

class DisplayFrame extends JFrame {
    DisplayFrame(String eno, String ename, String sal) {
        setTitle("Employee Details Display");
        setSize(300, 150);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel lblEno = new JLabel("Employee No: " + eno);
        lblEno.setBounds(20, 20, 250, 25);
        add(lblEno);

        JLabel lblEName = new JLabel("Employee Name: " + ename);
        lblEName.setBounds(20, 50, 250, 25);
        add(lblEName);

        JLabel lblSal = new JLabel("Salary: " + sal);
        lblSal.setBounds(20, 80, 250, 25);
        add(lblSal);

        setVisible(true);
    }
}
