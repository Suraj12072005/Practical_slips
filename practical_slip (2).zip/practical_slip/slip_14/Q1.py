# Slip 14 - Question 1 (Python)
import tkinter as tk
from tkinter import messagebox
import math

def calculate():
    try:
        r = float(entry_radius.get())
        h = float(entry_height.get())
        surface_area = 2 * math.pi * r * (r + h)
        volume = math.pi * r**2 * h
        result_var.set(f"Surface Area: {surface_area:.2f}\nVolume: {volume:.2f}")
    except ValueError:
        messagebox.showerror("Input Error", "Please enter valid numbers")

# Main window
root = tk.Tk()
root.title("Cylinder Calculator")

tk.Label(root, text="Radius:").pack(pady=5)
entry_radius = tk.Entry(root)
entry_radius.pack(pady=5)

tk.Label(root, text="Height:").pack(pady=5)
entry_height = tk.Entry(root)
entry_height.pack(pady=5)

tk.Button(root, text="Calculate", command=calculate).pack(pady=10)

result_var = tk.StringVar()
tk.Label(root, textvariable=result_var, font=("Arial", 12), fg="blue").pack(pady=10)

root.mainloop()
