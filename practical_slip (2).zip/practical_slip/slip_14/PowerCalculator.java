// Slip 14 - Question 1 (Java)
import java.util.Scanner;

public class PowerCalculator {

    // Recursive method to calculate power
    public static double power(double base, int exponent) {
        if (exponent == 0) {
            return 1; // base^0 = 1
        } else if (exponent > 0) {
            return base * power(base, exponent - 1);
        } else {
            // For negative exponent
            return 1 / power(base, -exponent);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter base: ");
        double base = sc.nextDouble();
        System.out.print("Enter exponent: ");
        int exponent = sc.nextInt();

        double result = power(base, exponent);
        System.out.println(base + " raised to the power " + exponent + " = " + result);
    }
}
