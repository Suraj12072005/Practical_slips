// Slip 26 - Question 2 (Java)
import java.applet.Applet;
import java.awt.*;

/*
<applet code="TempleApplet.class" width=500 height=400>
</applet>
*/

public class TempleApplet extends Applet {
    public void paint(Graphics g) {
        // Draw base
        g.setColor(Color.DARK_GRAY);
        g.fillRect(100, 250, 300, 100);

        // Draw pillars
        g.setColor(Color.GRAY);
        g.fillRect(120, 180, 20, 70);
        g.fillRect(360, 180, 20, 70);

        // Draw roof
        g.setColor(Color.RED);
        int[] xPoints = {100, 250, 400};
        int[] yPoints = {250, 150, 250};
        g.fillPolygon(xPoints, yPoints, 3);

        // Draw door
        g.setColor(Color.BLACK);
        g.fillRect(220, 280, 60, 70);
    }
}
