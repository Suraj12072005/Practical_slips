# Slip 26 - Question 1 (Python)
# Area of square using lambda

area_square = lambda side: side * side

# Area of rectangle using lambda
area_rectangle = lambda length, breadth: length * breadth

# Example usage
s = 5
l, b = 4, 6
print("Area of square:", area_square(s))
print("Area of rectangle:", area_rectangle(l, b))
