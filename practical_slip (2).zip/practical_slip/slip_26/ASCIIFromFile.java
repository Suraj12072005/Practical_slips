// Slip 26 - Question 1 (Java)
import java.io.*;

public class ASCIIFromFile {
    public static void main(String[] args) {
        String fileName = "input.txt"; // Replace with your file name

        try {
            FileReader fr = new FileReader(fileName);
            int ch;

            System.out.println("Character\tASCII Value");
            System.out.println("-------------------------");

            while ((ch = fr.read()) != -1) {
                System.out.println((char) ch + "\t\t" + ch);
            }

            fr.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + fileName);
        } catch (IOException e) {
            System.out.println("Error reading file");
        }
    }
}
