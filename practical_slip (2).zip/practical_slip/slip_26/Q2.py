# Slip 26 - Question 2 (Python)
from tkinter import *

def alter_sentence():
    text = entry.get()
    altered = ""
    for char in text:
        if char.isupper():
            altered += char.lower()
        elif char.islower():
            altered += char.upper()
        elif char.isdigit():
            altered += "?"
        elif char == " ":
            altered += "*"
        else:
            altered += char
    result_var.set(altered)

# Create GUI
root = Tk()
root.title("Sentence Alterer")

Label(root, text="Enter a sentence:").pack(pady=5)
entry = Entry(root, width=50)
entry.pack(pady=5)

Button(root, text="Alter Sentence", command=alter_sentence).pack(pady=5)

result_var = StringVar()
Label(root, textvariable=result_var, fg="blue").pack(pady=5)

root.mainloop()
