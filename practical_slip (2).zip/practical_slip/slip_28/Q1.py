# Program A: Tkinter Listbox Example
from tkinter import *

# Create main window
root = Tk()
root.title("Computer Science Courses")
root.geometry("300x300")

# Label
label = Label(root, text="List of Computer Science Courses", font=("Arial", 12, "bold"))
label.pack(pady=10)

# Create Listbox
course_listbox = Listbox(root, width=30, height=10, selectmode=SINGLE)
course_listbox.pack(pady=10)

# Add items to the Listbox
courses = [
    "Data Structures",
    "Algorithms",
    "Operating Systems",
    "Database Management Systems",
    "Computer Networks",
    "Artificial Intelligence",
    "Machine Learning",
    "Software Engineering",
    "Cyber Security",
    "Cloud Computing"
]

for course in courses:
    course_listbox.insert(END, course)

# Run the GUI event loop
root.mainloop()
