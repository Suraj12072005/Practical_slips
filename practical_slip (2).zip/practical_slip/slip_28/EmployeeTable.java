// Slip 28 - Question 2 (Java)
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class EmployeeTable {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Employee Details");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 300);

        String[] columnNames = {"Eno", "Ename", "Salary"};
        Object[][] data = {
            {101, "Alice", 50000},
            {102, "Bob", 55000},
            {103, "Charlie", 60000},
            {104, "David", 65000},
            {105, "Eva", 70000}
        };

        JTable table = new JTable(new DefaultTableModel(data, columnNames));
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane);

        frame.setVisible(true);
    }
}
