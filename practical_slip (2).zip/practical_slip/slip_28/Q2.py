# Program B: Merge Two Lists into List of Tuples

# Accept two lists from user
list1 = input("Enter first list elements separated by space: ").split()
list2 = input("Enter second list elements separated by space: ").split()

# Merge using zip() and convert to list of tuples
merged_list = list(zip(list1, list2))

# Display the result
print("List of tuples after merging:")
print(merged_list)
