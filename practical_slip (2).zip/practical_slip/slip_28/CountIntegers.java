// Slip 28 - Question 1 (Java)
public class CountIntegers {
    public static void main(String[] args) {
        int count = 10;

        for (String arg : args) {
            try {
                Integer.parseInt(arg);
                count++;
            } catch (NumberFormatException e) {
                // Not an integer, skip
            }
        }

        System.out.println("Number of integers in the list: " + count);
    }
}
