# Slip 3 - Question 1 (Python)
# Sample dictionary
my_dict = {'a': 10, 'b': 20, 'c': 30}

# Key to check
key_to_check = input("Enter the key to check: ")

if key_to_check in my_dict:
    print(f"Key '{key_to_check}' exists with value {my_dict[key_to_check]}")
    # Replace with new key/value
    new_key = input("Enter new key to replace: ")
    new_value = input("Enter new value: ")
    
    # Remove old key and add new key/value
    my_dict.pop(key_to_check)
    my_dict[new_key] = new_value
    print("Updated dictionary:", my_dict)
else:
    print(f"Key '{key_to_check}' does not exist in dictionary.")
