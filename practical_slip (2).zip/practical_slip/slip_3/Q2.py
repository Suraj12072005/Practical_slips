# Slip 3 - Question 2 (Python)
# Student class
class Student:
    def __init__(self, roll_no, name, age, gender):
        self.roll_no = roll_no
        self.name = name
        self.age = age
        self.gender = gender

    def display(self):
        print(f"Roll No: {self.roll_no}, Name: {self.name}, Age: {self.age}, Gender: {self.gender}")

# Test subclass
class Test(Student):
    def __init__(self, roll_no, name, age, gender, marks):
        super().__init__(roll_no, name, age, gender)
        self.marks = marks  # list of 3 subject marks
        self.total = sum(marks)

    def display(self):
        super().display()
        print(f"Marks: {self.marks}, Total Marks: {self.total}\n")

# Main program
students = []

# Creating 3 Test objects
for i in range(3):
    print(f"\nEnter details for student {i+1}:")
    roll_no = input("Roll No: ")
    name = input("Name: ")
    age = int(input("Age: "))
    gender = input("Gender: ")
    marks = []
    for j in range(1, 4):
        marks.append(int(input(f"Marks of subject {j}: ")))
    students.append(Test(roll_no, name, age, gender, marks))

# Display all students
print("\nAll student details:")
for s in students:
    s.display()

# Find student with maximum total marks
max_student = max(students, key=lambda x: x.total)
print("Student with maximum total marks:")
max_student.display()
