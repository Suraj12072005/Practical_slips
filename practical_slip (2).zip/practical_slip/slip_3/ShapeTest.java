// Slip 3 - Question 2 (Java)
import java.util.Scanner;

// Abstract class Shape
abstract class Shape {
    double radius;
    double height;

    Shape(double r, double h) {
        radius = r;
        height = h;
    }

    abstract double area();
    abstract double volume();
}

// Cone class
class Cone extends Shape {

    Cone(double r, double h) {
        super(r, h); // calling parent constructor
    }

    @Override
    double area() {
        double slantHeight = Math.sqrt(radius * radius + height * height);
        return Math.PI * radius * (radius + slantHeight); // surface area
    }

    @Override
    double volume() {
        return (1.0 / 3) * Math.PI * radius * radius * height;
    }
}

// Cylinder class
class Cylinder extends Shape {

    Cylinder(double r, double h) {
        super(r, h); // calling parent constructor
    }

    @Override
    double area() {
        return 2 * Math.PI * radius * (radius + height); // surface area
    }

    @Override
    double volume() {
        return Math.PI * radius * radius * height;
    }
}

// Main Program
public class ShapeTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter radius and height for Cone:");
        double r1 = sc.nextDouble();
        double h1 = sc.nextDouble();

        Cone cone = new Cone(r1, h1);
        System.out.println("Cone Surface Area: " + cone.area());
        System.out.println("Cone Volume: " + cone.volume());

        System.out.println("\nEnter radius and height for Cylinder:");
        double r2 = sc.nextDouble();
        double h2 = sc.nextDouble();

        Cylinder cylinder = new Cylinder(r2, h2);
        System.out.println("Cylinder Surface Area: " + cylinder.area());
        System.out.println("Cylinder Volume: " + cylinder.volume());

        sc.close();
    }
}
