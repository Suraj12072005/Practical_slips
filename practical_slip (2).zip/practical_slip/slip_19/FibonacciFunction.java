// Slip 19 - Question 1 (Java)
import java.util.Scanner;

public class FibonacciFunction {
    
    // Function to display Fibonacci series
    public static void fibonacci(int n) {
        int a = 0, b = 1;
        System.out.print("Fibonacci Series: " + a + " " + b + " ");
        for (int i = 3; i <= n; i++) {
            int c = a + b;
            System.out.print(c + " ");
            a = b;
            b = c;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of terms: ");
        int n = sc.nextInt();

        if (n <= 0) {
            System.out.println("Enter a positive number.");
        } else if (n == 1) {
            System.out.println("Fibonacci Series: 0");
        } else {
            fibonacci(n);
        }
        sc.close();
    }
}
