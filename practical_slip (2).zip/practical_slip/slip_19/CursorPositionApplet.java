// Slip 19 - Question 2 (Java)
import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

/* 
<applet code="CursorPositionApplet.class" width=400 height=300></applet>
*/

public class CursorPositionApplet extends Applet implements MouseMotionListener, KeyListener {
    int x = 0, y = 0;
    String keyPressed = "";

    public void init() {
        addMouseMotionListener(this);
        addKeyListener(this);
        setFocusable(true); // For keyboard events
    }

    public void paint(Graphics g) {
        g.clearRect(0, 0, getWidth(), getHeight());
        g.drawString("Mouse Position: X=" + x + " Y=" + y, 20, 50);
        g.drawString("Last Key Pressed: " + keyPressed, 20, 80);
    }

    // MouseMotionListener methods
    public void mouseMoved(MouseEvent e) {
        x = e.getX();
        y = e.getY();
        repaint();
    }

    public void mouseDragged(MouseEvent e) {
        x = e.getX();
        y = e.getY();
        repaint();
    }

    // KeyListener methods
    public void keyPressed(KeyEvent e) {
        keyPressed = KeyEvent.getKeyText(e.getKeyCode());
        repaint();
    }

    public void keyReleased(KeyEvent e) { }

    public void keyTyped(KeyEvent e) { }
}
