# Slip 19 - Question 2 (Python)
import math

# Base class
class Shape:
    def area(self):
        pass
    
    def volume(self):
        pass

# Subclass for Square
class Square(Shape):
    def __init__(self, length):
        self.length = length

    def area(self):
        return self.length * self.length

    def volume(self):
        return self.length ** 3  # Assuming cube volume

# Subclass for Circle
class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return math.pi * self.radius ** 2

    def volume(self):
        return (4/3) * math.pi * self.radius ** 3  # Sphere volume

# Example usage
s = Square(5)
c = Circle(3)

print("Square Area:", s.area())
print("Square Volume:", s.volume())
print("Circle Area:", round(c.area(), 2))
print("Circle Volume:", round(c.volume(), 2))
