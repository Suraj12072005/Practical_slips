# Slip 19 - Question 1 (Python)
import tkinter as tk
from tkinter import messagebox

def show_table():
    try:
        num = int(entry.get())
        result = ""
        for i in range(1, 11):
            result += f"{num} x {i} = {num*i}\n"
        text_area.config(state='normal')
        text_area.delete(1.0, tk.END)
        text_area.insert(tk.END, result)
        text_area.config(state='disabled')
    except ValueError:
        messagebox.showerror("Invalid Input", "Please enter a valid number")

# Create main window
root = tk.Tk()
root.title("Multiplication Table")

# Label and Entry
tk.Label(root, text="Enter a number:").pack(pady=5)
entry = tk.Entry(root)
entry.pack(pady=5)

# Button to display multiplication table
tk.Button(root, text="Show Table", command=show_table).pack(pady=5)

# Text widget to display results
text_area = tk.Text(root, height=12, width=30, state='disabled')
text_area.pack(pady=10)

root.mainloop()
