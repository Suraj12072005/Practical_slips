# Slip 18 - Question 2 (Python)
# Base class Person
class Person:
    def __init__(self, name, address):
        self.name = name
        self.address = address

# Subclass Employee
class Employee(Person):
    def __init__(self, name, address, salary):
        super().__init__(name, address)
        self.salary = salary

    def display(self):
        print(f"Name: {self.name}, Address: {self.address}, Salary: {self.salary}")

# Accept number of employees
n = int(input("Enter number of employees: "))

employees = []

# Input details for each employee
for i in range(n):
    print(f"\nEnter details for Employee {i+1}:")
    name = input("Name: ")
    address = input("Address: ")
    salary = float(input("Salary: "))
    employees.append(Employee(name, address, salary))

# Display employee details
print("\nEmployee Details:")
for emp in employees:
    emp.display()
