// Slip 18 - Question 2 (Java)
import java.io.*;

public class FileCopyTransform {
    public static void main(String[] args) {
        File sourceFile = new File("source.txt");
        File targetFile = new File("target.txt");

        try (FileReader fr = new FileReader(sourceFile);
             FileWriter fw = new FileWriter(targetFile)) {

            int c;
            while ((c = fr.read()) != -1) {
                char ch = (char) c;

                // Replace digits with '*'
                if (Character.isDigit(ch)) {
                    ch = '*';
                }
                // Change case
                else if (Character.isUpperCase(ch)) {
                    ch = Character.toLowerCase(ch);
                } else if (Character.isLowerCase(ch)) {
                    ch = Character.toUpperCase(ch);
                }

                fw.write(ch);
            }

            System.out.println("File copied successfully with transformations.");
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}
