# Slip 18 - Question 1 (Python)
# Given list
a = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]

# Using list comprehension to filter elements less than 5
less_than_five = [x for x in a if x < 5]

print("Elements less than 5:", less_than_five)
