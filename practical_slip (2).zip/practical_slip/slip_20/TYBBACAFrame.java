// Slip 20 - Question 1 (Java)
import java.awt.*;
import java.awt.event.*;

public class TYBBACAFrame {
    public static void main(String[] args) {
        // Create a frame
        Frame f = new Frame("TYBBACA");

        // Set background color to red
        f.setBackground(Color.RED);

        // Set size and layout
        f.setSize(400, 300);
        f.setLayout(new FlowLayout());

        // Close window when user clicks close button
        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                f.dispose();
            }
        });

        // Make frame visible
        f.setVisible(true);
    }
}
