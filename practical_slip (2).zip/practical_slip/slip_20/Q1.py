# Slip 20 - Question 1 (Python)
import math

class Circle:
    # Parameterized constructor
    def __init__(self, radius):
        self.radius = radius

    # Method to calculate area
    def area(self):
        return math.pi * self.radius * self.radius

    # Method to calculate circumference
    def circumference(self):
        return 2 * math.pi * self.radius

# Accept input from user
r = float(input("Enter radius of the circle: "))

# Create Circle object
circle = Circle(r)

# Display results
print("Area of the circle:", round(circle.area(), 2))
print("Circumference of the circle:", round(circle.circumference(), 2))
