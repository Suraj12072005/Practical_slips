// Slip 20 - Question 2 (Java)
import java.util.*;

public class LinkedListExample {
    public static void main(String[] args) {
        // Construct LinkedList
        LinkedList<String> languages = new LinkedList<>();
        languages.add("CPP");
        languages.add("Java");
        languages.add("Python");
        languages.add("PHP");

        // i. Display contents using Iterator
        System.out.println("Contents using Iterator:");
        Iterator<String> it = languages.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }

        // ii. Display contents in reverse using ListIterator
        System.out.println("\nContents in reverse using ListIterator:");
        ListIterator<String> listIt = languages.listIterator(languages.size());
        while (listIt.hasPrevious()) {
            System.out.println(listIt.previous());
        }
    }
}
