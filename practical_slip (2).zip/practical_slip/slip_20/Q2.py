# Slip 20 - Question 2 (Python)
# Accept n from user
n = int(input("Enter a number n: "))

# Generate dictionary using dictionary comprehension
square_dict = {x: x*x for x in range(1, n+1)}

print("Generated Dictionary:", square_dict)
