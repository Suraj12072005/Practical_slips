# Slip 8 - Question 2 (Python)
class StringManipulator:
    def __init__(self):
        self.text = ""

    def get_String(self):
        self.text = input("Enter a string: ")

    def print_String(self):
        # Print string in uppercase
        print("Uppercase:", self.text.upper())

    def reverse_words_lower(self):
        # Reverse the string word by word and print in lowercase
        reversed_words = ' '.join(self.text.split()[::-1])
        print("Reversed words (lowercase):", reversed_words.lower())

# Example usage
sm = StringManipulator()
sm.get_String()
sm.print_String()
sm.reverse_words_lower()
