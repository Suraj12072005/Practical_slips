// Slip 8 - Question 2 (Java)
import java.io.File;
import java.util.Scanner;

public class TxtFileDisplay {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter directory path: ");
        String dirPath = sc.nextLine();

        File dir = new File(dirPath);

        if (dir.isDirectory()) {
            File[] files = dir.listFiles();
            System.out.println(".txt files in directory:");
            for (File f : files) {
                if (f.isFile() && f.getName().endsWith(".txt")) {
                    System.out.println(f.getName());
                }
            }
        } else {
            System.out.println("Invalid directory path!");
        }

        sc.close();
    }
}
