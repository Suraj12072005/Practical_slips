// Slip 8 - Question 1 (Java)
import java.util.Scanner;

// Interface Shape
interface Shape {
    double area();
}

// Circle class implementing Shape
class Circle implements Shape {
    private final double radius;  // final variable

    Circle(double r) {
        this.radius = r;
    }

    @Override
    public double area() {
        return Math.PI * radius * radius;
    }
}

// Sphere class implementing Shape
class Sphere implements Shape {
    private final double radius;  // final variable

    Sphere(double r) {
        this.radius = r;
    }

    @Override
    public double area() {
        return 4 * Math.PI * radius * radius; // surface area of sphere
    }
}

// Main Program
public class ShapeAreaTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter radius for Circle: ");
        double r1 = sc.nextDouble();
        Circle circle = new Circle(r1);
        System.out.println("Area of Circle: " + circle.area());

        System.out.print("Enter radius for Sphere: ");
        double r2 = sc.nextDouble();
        Sphere sphere = new Sphere(r2);
        System.out.println("Surface Area of Sphere: " + sphere.area());

        sc.close();
    }
}
