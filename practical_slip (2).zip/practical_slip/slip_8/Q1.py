# Slip 8 - Question 1 (Python)
# Sample tuple
t = (1, 2, 3, 2, 4, 1, 5, 3, 6, 2)

# Using dictionary to count occurrences
repeated_items = {item: t.count(item) for item in set(t) if t.count(item) > 1}

print("Tuple:", t)
print("Repeated items with count:", repeated_items)
