// Slip 27 - Question 1 (Java)
import java.util.Scanner;

// User-defined exception class
class OutOfRangeException extends Exception {
    public OutOfRangeException(String message) {
        super(message);
    }
}

public class NumberFactors {
    // Static method to calculate and display factors
    public static void displayFactors(int number) {
        System.out.println("Factors of " + number + " are:");
        for (int i = 1; i <= number; i++) {
            if (number % i == 0) {
                System.out.print(i + " ");
            }
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter a number: ");
            int number = scanner.nextInt();

            // Check if the number is greater than 1000
            if (number > 1000) {
                throw new OutOfRangeException("Number is out of Range");
            }

            // Call the static method to display factors
            displayFactors(number);

        } catch (OutOfRangeException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a valid number.");
        } finally {
            scanner.close();
        }
    }
}
