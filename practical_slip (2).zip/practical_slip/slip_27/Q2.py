from tkinter import *

def convert():
    try:
        n = int(entry.get())
        bin_var.set("Binary: " + bin(n)[2:])
        oct_var.set("Octal: " + oct(n)[2:])
        hex_var.set("Hexadecimal: " + hex(n)[2:].upper())
    except:
        bin_var.set(oct_var.set(hex_var.set("Invalid input")))

root = Tk()
root.title("Decimal Converter")

Entry(root).pack(pady=5)
entry = Entry(root)
entry.pack(pady=5)

Button(root, text="Convert", command=convert).pack(pady=5)

bin_var = StringVar(); oct_var = StringVar(); hex_var = StringVar()
Label(root, textvariable=bin_var).pack()
Label(root, textvariable=oct_var).pack()
Label(root, textvariable=hex_var).pack()

root.mainloop()
