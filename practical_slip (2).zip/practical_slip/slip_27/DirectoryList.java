// Slip 27 - Question 2 (Java)
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class DirectoryList extends Frame implements ActionListener {
    Label label;
    TextField dirField;
    Button showButton;
    List fileList;

    public DirectoryList() {
        // Set up Frame
        setTitle("Directory File List");
        setSize(500, 400);
        setLayout(new FlowLayout());
        setBackground(Color.lightGray);

        // Create components
        label = new Label("Enter Directory Path:");
        dirField = new TextField(30);
        showButton = new Button("Show Files");
        fileList = new List(15, false);

        // Add components to Frame
        add(label);
        add(dirField);
        add(showButton);
        add(fileList);

        // Add event listener
        showButton.addActionListener(this);

        // Handle window close
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        fileList.removeAll(); // clear previous list

        String dirName = dirField.getText();
        File dir = new File(dirName);

        if (dir.exists() && dir.isDirectory()) {
            String[] files = dir.list();
            if (files != null) {
                for (String file : files) {
                    fileList.add(file);
                }
            }
        } else {
            fileList.add("Invalid directory name!");
        }
    }

    public static void main(String[] args) {
        new DirectoryList();
    }
}
