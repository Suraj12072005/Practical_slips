# Slip 4 - Question 2 (Python)
# Employee class
class Employee:
    def __init__(self):
        self.id = 0
        self.name = ""
        self.department = ""
        self.salary = 0.0

    def accept(self):
        self.id = int(input("Enter Employee ID: "))
        self.name = input("Enter Employee Name: ")
        self.department = input("Enter Department: ")
        self.salary = float(input("Enter Salary: "))

    def display(self):
        print(f"ID: {self.id}, Name: {self.name}, Department: {self.department}, Salary: {self.salary}")

# Manager subclass
class Manager(Employee):
    def __init__(self):
        super().__init__()
        self.bonus = 0.0

    def accept(self):
        super().accept()
        self.bonus = float(input("Enter Bonus: "))

    def display(self):
        total_salary = self.salary + self.bonus
        print(f"ID: {self.id}, Name: {self.name}, Department: {self.department}, "
              f"Salary: {self.salary}, Bonus: {self.bonus}, Total Salary: {total_salary}")

# Main program
n = int(input("Enter number of managers: "))
managers = []

for i in range(n):
    print(f"\nEnter details for manager {i+1}:")
    m = Manager()
    m.accept()
    managers.append(m)

# Find manager with maximum total salary
max_manager = max(managers, key=lambda x: x.salary + x.bonus)

print("\nManager with maximum total salary:")
max_manager.display()
