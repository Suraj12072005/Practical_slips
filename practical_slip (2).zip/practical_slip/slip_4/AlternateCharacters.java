// Program A: Display alternate characters from a given string
import java.util.Scanner;

public class AlternateCharacters {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String str = sc.nextLine();

        System.out.print("Alternate characters: ");
        for (int i = 0; i < str.length(); i += 2) {  // step by 2
            System.out.print(str.charAt(i));
        }

        System.out.println();
        sc.close();
    }
}
