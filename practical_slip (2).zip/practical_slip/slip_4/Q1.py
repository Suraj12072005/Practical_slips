# Slip 4 - Question 1 (Python)
import tkinter as tk
import random

def change_color():
    # Generate random color in hex format
    color = f'#{random.randint(0, 0xFFFFFF):06x}'
    root.config(bg=color)
    # Call this function again after 500 milliseconds
    root.after(500, change_color)

# Create main window
root = tk.Tk()
root.title("Changing Background Colors")
root.geometry("400x300")

# Start changing colors
change_color()

root.mainloop()
