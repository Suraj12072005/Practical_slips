# Slip 21 - Question 2 (Python)
# Original tuple
tup = (('333', '33'), ('1416', '55'))

# Convert string values to integers using nested tuple comprehension
new_tup = tuple(tuple(int(x) for x in inner) for inner in tup)

print("Original tuple values:", tup)
print("New tuple values:", new_tup)
