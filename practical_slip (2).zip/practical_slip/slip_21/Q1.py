# Slip 21 - Question 1 (Python)
class Rectangle:
    def __init__(self, length, width):
        self.length = length
        self.width = width

    # Method to compute area
    def area(self):
        return self.length * self.width

    # Method to compute perimeter
    def perimeter(self):
        return 2 * (self.length + self.width)

# Accept input from user
l = float(input("Enter length of rectangle: "))
w = float(input("Enter width of rectangle: "))

# Create object
rect = Rectangle(l, w)

# Display results
print("Area of rectangle:", rect.area())
print("Perimeter of rectangle:", rect.perimeter())
