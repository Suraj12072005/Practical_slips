// Slip 21 - Question 2 (Java)
import java.util.Hashtable;
import java.util.Scanner;
import java.util.Enumeration;

public class CitySTDHashtable {
    public static void main(String[] args) {
        // Create hashtable
        Hashtable<String, String> cityStd = new Hashtable<>();

        // Adding city names and STD codes
        cityStd.put("Mumbai", "022");
        cityStd.put("Delhi", "011");
        cityStd.put("Bangalore", "080");
        cityStd.put("Chennai", "044");
        cityStd.put("Kolkata", "033");

        // Display hashtable details
        System.out.println("City\tSTD Code");
        Enumeration<String> cities = cityStd.keys();
        while (cities.hasMoreElements()) {
            String city = cities.nextElement();
            System.out.println(city + "\t" + cityStd.get(city));
        }

        // Search for a specific city
        Scanner sc = new Scanner(System.in);
        System.out.print("\nEnter city to search STD code: ");
        String searchCity = sc.nextLine();

        if (cityStd.containsKey(searchCity)) {
            System.out.println("STD code of " + searchCity + " is " + cityStd.get(searchCity));
        } else {
            System.out.println("City not found in the hashtable.");
        }

        sc.close();
    }
}
