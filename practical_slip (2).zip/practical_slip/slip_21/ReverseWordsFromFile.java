// Slip 21 - Question 1 (Java)
import java.io.*;
import java.util.Scanner;

public class ReverseWordsFromFile {
    public static void main(String[] args) {
        try {
            File file = new File("input.txt"); // Make sure input.txt exists
            Scanner sc = new Scanner(file);

            while (sc.hasNext()) {
                String word = sc.next();
                String reversed = new StringBuilder(word).reverse().toString();
                System.out.println(reversed);
            }

            sc.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }
    }
}
