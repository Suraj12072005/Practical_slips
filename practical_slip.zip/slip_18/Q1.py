# Slip 18 - Question 1 (Python)
print('Slip 18 - Question 1')