# Slip 18 - Question 2 (Python)
print('Slip 18 - Question 2')