# Slip 9 - Question 1 (Python)
print('Slip 9 - Question 1')