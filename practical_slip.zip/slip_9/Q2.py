# Slip 9 - Question 2 (Python)
print('Slip 9 - Question 2')