# Slip 19 - Question 1 (Python)
print('Slip 19 - Question 1')