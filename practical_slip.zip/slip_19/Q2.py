# Slip 19 - Question 2 (Python)
print('Slip 19 - Question 2')