# Slip 20 - Question 1 (Python)
print('Slip 20 - Question 1')