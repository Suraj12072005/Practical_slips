# Slip 20 - Question 2 (Python)
print('Slip 20 - Question 2')