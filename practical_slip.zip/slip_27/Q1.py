# Slip 27 - Question 1 (Python)
print('Slip 27 - Question 1')