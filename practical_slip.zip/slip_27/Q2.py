# Slip 27 - Question 2 (Python)
print('Slip 27 - Question 2')