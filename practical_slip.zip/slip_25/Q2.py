# Slip 25 - Question 2 (Python)
print('Slip 25 - Question 2')