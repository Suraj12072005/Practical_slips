# Slip 25 - Question 1 (Python)
print('Slip 25 - Question 1')