# Slip 4 - Question 1 (Python)
print('Slip 4 - Question 1')