# Slip 4 - Question 2 (Python)
print('Slip 4 - Question 2')