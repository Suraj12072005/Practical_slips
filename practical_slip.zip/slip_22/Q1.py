# Slip 22 - Question 1 (Python)
print('Slip 22 - Question 1')