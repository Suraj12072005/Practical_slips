# Slip 22 - Question 2 (Python)
print('Slip 22 - Question 2')