# Slip 17 - Question 1 (Python)
print('Slip 17 - Question 1')