# Slip 17 - Question 2 (Python)
print('Slip 17 - Question 2')