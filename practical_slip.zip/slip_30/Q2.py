# Slip 30 - Question 2 (Python)
print('Slip 30 - Question 2')