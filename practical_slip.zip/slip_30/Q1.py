# Slip 30 - Question 1 (Python)
print('Slip 30 - Question 1')