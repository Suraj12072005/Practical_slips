# Slip 28 - Question 2 (Python)
print('Slip 28 - Question 2')