# Slip 28 - Question 1 (Python)
print('Slip 28 - Question 1')