# Slip 23 - Question 2 (Python)
print('Slip 23 - Question 2')