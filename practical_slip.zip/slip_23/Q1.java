// Slip 23 - Question 1 (Java)
public class Q1 {
    public static void main(String[] args) {
        System.out.println("Slip {i} - Question {q}");
    }
}