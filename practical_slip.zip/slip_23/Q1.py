# Slip 23 - Question 1 (Python)
print('Slip 23 - Question 1')