# Slip 29 - Question 2 (Python)
print('Slip 29 - Question 2')