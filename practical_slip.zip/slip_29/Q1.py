# Slip 29 - Question 1 (Python)
print('Slip 29 - Question 1')