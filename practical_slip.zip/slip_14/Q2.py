# Slip 14 - Question 2 (Python)
print('Slip 14 - Question 2')