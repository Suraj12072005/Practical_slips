# Slip 14 - Question 1 (Python)
print('Slip 14 - Question 1')