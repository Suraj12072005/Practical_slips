# Slip 12 - Question 1 (Python)
print('Slip 12 - Question 1')