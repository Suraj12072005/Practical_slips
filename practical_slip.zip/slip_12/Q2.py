# Slip 12 - Question 2 (Python)
print('Slip 12 - Question 2')