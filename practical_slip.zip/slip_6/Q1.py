# Slip 6 - Question 1 (Python)
print('Slip 6 - Question 1')