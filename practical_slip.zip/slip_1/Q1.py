# Slip 1 - Question 1 (Python)
print('Slip 1 - Question 1')