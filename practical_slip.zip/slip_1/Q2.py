# Slip 1 - Question 2 (Python)
print('Slip 1 - Question 2')