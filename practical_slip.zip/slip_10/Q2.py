# Slip 10 - Question 2 (Python)
print('Slip 10 - Question 2')