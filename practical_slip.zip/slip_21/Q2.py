# Slip 21 - Question 2 (Python)
print('Slip 21 - Question 2')