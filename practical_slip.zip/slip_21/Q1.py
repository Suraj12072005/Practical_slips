# Slip 21 - Question 1 (Python)
print('Slip 21 - Question 1')