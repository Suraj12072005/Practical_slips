# Slip 3 - Question 2 (Python)
print('Slip 3 - Question 2')