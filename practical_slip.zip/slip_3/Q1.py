# Slip 3 - Question 1 (Python)
print('Slip 3 - Question 1')