# Slip 11 - Question 2 (Python)
print('Slip 11 - Question 2')