# Slip 11 - Question 1 (Python)
print('Slip 11 - Question 1')