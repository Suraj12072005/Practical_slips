# Slip 7 - Question 1 (Python)
print('Slip 7 - Question 1')