# Slip 7 - Question 2 (Python)
print('Slip 7 - Question 2')