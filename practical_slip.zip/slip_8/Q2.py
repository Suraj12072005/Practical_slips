# Slip 8 - Question 2 (Python)
print('Slip 8 - Question 2')