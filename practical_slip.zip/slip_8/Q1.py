# Slip 8 - Question 1 (Python)
print('Slip 8 - Question 1')