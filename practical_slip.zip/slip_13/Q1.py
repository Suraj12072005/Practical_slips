# Slip 13 - Question 1 (Python)
print('Slip 13 - Question 1')