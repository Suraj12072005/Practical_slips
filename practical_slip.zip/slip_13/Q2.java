// Slip 13 - Question 2 (Java)
public class Q2 {
    public static void main(String[] args) {
        System.out.println("Slip {i} - Question {q}");
    }
}