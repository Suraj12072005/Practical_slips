# Slip 15 - Question 1 (Python)
print('Slip 15 - Question 1')