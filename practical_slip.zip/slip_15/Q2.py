# Slip 15 - Question 2 (Python)
print('Slip 15 - Question 2')