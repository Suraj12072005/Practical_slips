# Slip 16 - Question 1 (Python)
print('Slip 16 - Question 1')