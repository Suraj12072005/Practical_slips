# Slip 16 - Question 2 (Python)
print('Slip 16 - Question 2')