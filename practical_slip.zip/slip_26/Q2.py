# Slip 26 - Question 2 (Python)
print('Slip 26 - Question 2')