# Slip 26 - Question 1 (Python)
print('Slip 26 - Question 1')