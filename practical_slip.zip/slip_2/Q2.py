# Slip 2 - Question 2 (Python)
print('Slip 2 - Question 2')