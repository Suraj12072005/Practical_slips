# Slip 2 - Question 1 (Python)
print('Slip 2 - Question 1')