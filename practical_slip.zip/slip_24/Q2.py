# Slip 24 - Question 2 (Python)
print('Slip 24 - Question 2')