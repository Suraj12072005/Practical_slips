# Slip 24 - Question 1 (Python)
print('Slip 24 - Question 1')