# Slip 5 - Question 1 (Python)
print('Slip 5 - Question 1')