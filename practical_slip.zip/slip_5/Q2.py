# Slip 5 - Question 2 (Python)
print('Slip 5 - Question 2')